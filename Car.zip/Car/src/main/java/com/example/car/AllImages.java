package com.example.car;

import javafx.fxml.FXML;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;

import java.io.File;


//public class AllImages {
//
//    @FXML
//    private ImageView carImage;
//
//    @FXML
//    private ImageView suzukiImg;
//
//
//
//    public void loginImage(){
//        File carFile = new File("C:\\Users\\user\\Desktop\\Car\\src\\Images\\car.png");
//        Image carView = new Image(carFile.toURI().toString());
//        carImage.setImage(carView);
//
//        File suzukiFile = new File("C:\\Users\\user\\Desktop\\Car\\src\\Images\\maruti-group-m.jpg");
//        Image suzukiView = new Image(suzukiFile.toURI().toString());
//        suzukiImg.setImage(suzukiView);
//
//    }
//}
