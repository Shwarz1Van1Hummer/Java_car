package DBConnection;

public class Configs {

    protected static String dbhost = "localhost";
    protected static String dbport = "8080";
    protected static String dbuser = "postgres";
    protected static String dbpass = "Alma";
    protected static String dbname = "genus";

}
